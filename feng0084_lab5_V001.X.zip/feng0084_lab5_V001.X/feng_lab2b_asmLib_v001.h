/* 
 * File:   feng_lab2b_asmLib_v001.h
 * Author: Fengj
 *
 * Created on February 17, 2019, 3:35 PM
 */

#ifndef FENG_LAB2B_ASMLIB_V001_H
#define	FENG_LAB2B_ASMLIB_V001_H

#ifdef	__cplusplus
extern "C" {
#endif

void micro_wait(void);
void ms_wait(void);
void write_0(void);
void write_1(void);



#ifdef	__cplusplus
}
#endif

#endif	/* FENG_LAB2B_ASMLIB_V001_H */

